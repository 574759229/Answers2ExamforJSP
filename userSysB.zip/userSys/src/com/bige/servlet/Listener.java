package com.bige.servlet;


import java.util.ArrayList;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;


public class Listener implements ServletContextListener{
	
   public void contextInitialized(ServletContextEvent arg0) {
	   // TODO Auto-generated method stub
	   ArrayList<String> obj = new ArrayList<String>();
	   obj.add("1");
	   obj.add("2");
	   obj.add("3");
       new Init().setList(obj);
       System.out.println("初始化完毕");
     }

     public void contextDestroyed(ServletContextEvent arg0) {
	  // TODO 退出代码
	
     }

}
