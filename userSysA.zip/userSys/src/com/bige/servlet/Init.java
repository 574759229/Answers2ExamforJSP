package com.bige.servlet;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class Init {
	private String name ="变量读取测试";
	private List<String> list;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setList(List<String> list) {
		list.add("1");
		list.add("2");
		list.add("3");
		this.list = list;
	}
	
	public List<String> getList() {
		return list;
	}
	
	
	
	@SuppressWarnings({ "rawtypes", "unchecked" })
	public List test() {
		List<Map<String,String>> list = new ArrayList<Map<String,String>>(); 
		Map map = new HashMap();
		map.put("e_name","zhangsan");
		map.put("c_name","张三");
		map.put("bth_day","19811224");
		map.put("sex","女");
		list.add(map);
		map = new HashMap();
		map.put("e_name","lisi");
		map.put("c_name","李四");
		map.put("bth_day","19770805");
		map.put("sex","男");
		list.add(map);
		map = new HashMap();
		map.put("e_name","wangwu");
		map.put("c_name","王五");
		map.put("bth_day","19830924");
		map.put("sex","女");
		list.add(map);
		return list;
	}

}
