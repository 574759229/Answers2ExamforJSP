package com.bige.database;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * Servlet implementation class FindServlet
 */
@WebServlet("/FindServlet")
public class FindServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	final String url = "jdbc:mysql://localhost:3306/UserDB";
	final String username = "root";
	final String password = "heiduiyun.com";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public FindServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String type = request.getParameter("type");
		String value = request.getParameter("value");
		if("search".equals(type)) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection conn = DriverManager.getConnection(url,username,password);
				Statement stmt = conn.createStatement();
				String sql = "select * from userInfo";
				ResultSet rs = stmt.executeQuery(sql);
				List<UserInfo> list = new ArrayList<UserInfo>();
				while(rs.next()) {
					UserInfo userInfo = new UserInfo();
					userInfo.setUsername(rs.getString("username"));
					userInfo.setPassword(rs.getString("password"));
					list.add(userInfo);
				}
				request.setAttribute("list", list);
				rs.close();
				stmt.close();
				conn.close();
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println("请确保mysql驱动jar已配置");
			}catch (SQLException e) {
				e.printStackTrace();
				System.out.println("SQLException类崩溃:" + e.getMessage());
			}
			request.getRequestDispatcher("list.jsp").forward(request, response);
			return;
		}if("delete".equals(type)) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
				Connection conn = DriverManager.getConnection(url,username,password);
				Statement stmt = conn.createStatement();
				String sql = "delete from userInfo where username = '"+ value + "'";
				Statement statement = conn.createStatement();
				statement.executeUpdate(sql);
				statement.close();
				request.setAttribute("message", "删除成功！");
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				request.setAttribute("message", e.getMessage());
				System.out.println("请确保mysql驱动jar已配置");
			}catch (SQLException e) {
				e.printStackTrace();
				System.out.println("SQLException类崩溃:" + e.getMessage());
			}
			request.getRequestDispatcher("delete.jsp").forward(request, response);
			return;
		}				
	}


}
